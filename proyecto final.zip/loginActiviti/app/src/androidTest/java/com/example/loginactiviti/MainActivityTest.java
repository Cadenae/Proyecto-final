package com.example.loginactiviti;

import junit.framework.TestCase;

public class MainActivityTest extends TestCase {

}